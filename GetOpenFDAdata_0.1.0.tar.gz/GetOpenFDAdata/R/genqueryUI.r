
myreplist <- list("chkrecdate", "chkprisource", "chkserious", "chksendtert", "chkreceiver")
mypatlist <- list("chkpoage", "chkpgender", "chkpweight")
mydrglist <- list("chkmedprod", "chkmedprod", "chkgenname", "chkgenname")
myptslist <- list("chkpts")

appgenquerryui <- shinyApp(
  ui = shinyUI(
    fluidPage(theme = "bootstrap.css",
      tags$head(
         tags$style(HTML("h2 {
           font-family: 'Lobster', cursive;
           font-weight: 500;
           line-height: 1.1;
           color: #3366aa;
           }" )
      )
    ),
    titlePanel("Generate query for the openFDA website"),
    fluidRow(
      column(3,tags$h3("Select Criteria:"),
        wellPanel(
          checkboxGroupInput("sourcerep",
            label = "About the report:",
            choices = list(
              "Receive Date" = "chkrecdate",
              "Primary source" = "chkprisource",
              "Seriousness" = "chkserious",
              "[x]Sender type" = "chksendtert",
              "[x]Receiver type" = "chkreceiver"
            )
          ),
          checkboxGroupInput("sourcepat",
                                    label = "About the patient:",
                                    choices = list("Onset age" = "chkpoage",
                                                   "Gender" = "chkpgender",
                                                   "Weight" = "chkpweight")),
                 checkboxGroupInput("sourcedrg",
                                    label = "About the drug:",
                                    choices = list("Product name" = "chkmedprod",
                                                   "Generic name" = "chkgenname")),
                 checkboxGroupInput("sourcepts",
                                    label = "About the PT:",
                                    choices = list("Prefered term" = "chkpts")),
                 selectInput("sourcertn",
                             label = "Select output type:",
                             choices = c(
                               "show the count of selected reports"="c",
                               "View one report" ="r",
                               "Show counts by PT"  ="p",
                               "Show counts by drug"="d"
                             ),
                             selected = "r")
               ) #wellPanel
        ), #column-3
        column(9,
               tabsetPanel(
                 tabPanel("Set values for selected criteria",
                          fluidRow(
                            column(6, uiOutput("sourceuirep")),
                            column(6, uiOutput("sourceuipat"))
                          ),
                          fluidRow(
                            column(6, uiOutput("sourceuidrg")),
                            column(6, uiOutput("sourceuipts"))
                          ),
                          fluidRow(
                            tags$h3("Query:"),
                            column(12,
                                   verbatimTextOutput("myquery"),
                                   list(
                                     actionButton("mycopy", "Copy to clipboard", class="btn btn-info"),
                                     uiOutput("mysubmit")
                                     #                    , actionButton("myjview", "View results in JSON format", class="btn btn-info")
                                   )
                            )
                          ) #fluidRow
                 ),#tabPanel
                 tabPanel("About", column(12, source(file="./R/info/about.r")))
               ) #tabsetPanel
        ) #column-9
      ), #fluidRow-12
      fluidRow(tags$hr(), source(file="./R/info/footnote.r"))
    )#fluidPage
  ),#shinyUI

  ### for tab: guery ##################################################################
  server = shinyServer(function(input, output, session) {
    values <- reactiveValues()
    output$sourceuirep <- renderUI({
      if(is.null(input$sourcerep)){wellPanel(
        tags$b("About the report:"),tags$br()
      )}else{
        ischkmyreplist <- rep(FALSE, length(myreplist))
        for( myidx in 1:length(myreplist)){
          ischkmyreplist[myidx] <- grepl(myreplist[myidx], paste(input$sourcerep, collapse=" ") )
        }
        wellPanel(tags$b("About the report:"),tags$br(),list(
          dateRangeInput("setrecdate", "Receive date range:",
                         start  = "2015-01-01",
                         end    = "2015-01-31",
                         min    = "1996-01-01",
                         max    = "2015-12-21",
                         format = "yyyy-mm-dd",
                         separator = " to "),
          selectInput("setprisource", "Primary source qualification (An encoded value for the category of individual submitting the report): ",
                      choices = c(
                        "1 Physician"="1",
                        "2 Pharmacist"="2",
                        "3 Other Health Professional"="3",
                        "4 Lawyer"="4",
                        "5 Consumer or non-health professional"="5"),
                      selected = "1"),
          selectInput("setserious", "Seriousness:",
                      choices = c(
                        "1 The adverse event resulted in death, a life threatening condition, hospitalization, disability, congenital anomali, or other serious condition."="1",
                        "2 The adverse event did not result in any of the above."="2"),
                      selected = "1"),
          selectInput("setsendert", "Sender type:",
                      choices = c(
                        "1 Pharmaceutical Company (p=0)"="1",
                        "2 Regulatory Authority (p=1)"="2",
                        "3 Health Professional (p=0)"="3",
                        "4 Regional Pharmacovigilance Center (p=0)"="4",
                        "5 WHO Collaborating Center for International Drug Monitoring  (p=0)"="5",
                        "6 Other (p=0)"="6"),
                      selected = "2"),
          selectInput("setreceiver", "Receiver type (The name of the organization receiving the report.): ",
                      choices = c(
                        "1 Pharmaceutical Company (p=0)"="1",
                        "2 Regulatory Authority (p=0)"="2",
                        "3 Health Professional (p=0)"="3",
                        "4 Regional Pharmacovigilance Center (p=0)"="4",
                        "5 WHO Collaborating Center for International Drug Monitoring (p=0)"="5",
                        "6 Other (p=1)"="6"),
                      selected = "6")
        )[ischkmyreplist])
      }
    })

    output$sourceuipat <- renderUI({
      # Depending on input$input_type, we'll generate a different
      # UI component and send it to the client.
      if(is.null(input$sourcepat)){wellPanel(
        tags$b("About the patient:"),tags$br()
      )}else{
        ischkmypatlist <- rep(FALSE, length(mypatlist))
        for( myidx in 1:length(mypatlist)){
          ischkmypatlist[myidx] <- grepl(mypatlist[myidx], paste(input$sourcepat, collapse=" ") )
        }
        wellPanel(tags$b("About the patient:"),tags$br(),list(
          sliderInput("setonsetage", label="Onset age:",
                      min = 0, max = 100, value = c(25,75)),
          radioButtons("setpgender", label="Gender:", choices=list(
            "Female"  = "2",
            "Male"    = "1",
            "Unknown" = "0"), selected="2"),
          sliderInput("setpweight", label="Weight:",
                      min = 0, max = 300, value =c(25,75))
        )[ischkmypatlist])
      }
    })

    output$sourceuidrg <- renderUI({
      if(is.null(input$sourcedrg)){wellPanel(
        tags$b("About the drug:"),tags$br()
      )}else{
        ischkmydrglist <- rep(FALSE, length(mydrglist))
        for( myidx in 1:length(mydrglist)){
          ischkmydrglist[myidx] <- grepl(mydrglist[myidx], paste(input$sourcedrg, collapse=" ") )
        }
        wellPanel(tags$b("About the drug:"),tags$br(),list(
          textInput("setdmedname", "Product name:",value=""),
          checkboxInput("setdmednameexact", "Exact match?"),
          textInput("setdgenname", "Generic name:",value=""),
          checkboxInput("setdgennameexact", "Exact match?")
        )[ischkmydrglist])
      }
    })

    output$sourceuipts <- renderUI({
      if(is.null(input$sourcepts)){wellPanel(
        tags$b("About the PT:"),tags$br()
      )}else{
        ischkmyptslist <- rep(FALSE, length(myptslist))
        for( myidx in 1:length(myptslist)){
          ischkmyptslist[myidx] <- grepl(myptslist[myidx], paste(input$sourcepts, collapse=" ") )
        }
        wellPanel(tags$b("About the PT:"),tags$br(),list(
          textInput("setpt", "Prefered term:",value=""),
          checkboxInput("setptexact", "Exact match?")
        )[ischkmyptslist])
      }
    })

    output$input_type_text <- renderText({
      paste(input$sourcerep, (input$sourcerep==myreplist) )
    })

    myurl <- function(){
      ischkmyreplist <- rep(FALSE, length(myreplist))
      for( myidx in 1:length(myreplist)){
        ischkmyreplist[myidx] <- grepl(myreplist[myidx], paste(input$sourcerep, collapse=" ") )
      }
      ischkmypatlist <- rep(FALSE, length(mypatlist))
      for( myidx in 1:length(mypatlist)){
        ischkmypatlist[myidx] <- grepl(mypatlist[myidx], paste(input$sourcepat, collapse=" ") )
      }
      ischkmydrglist <- rep(FALSE, length(mydrglist))
      for( myidx in 1:length(mydrglist)){
        ischkmydrglist[myidx] <- grepl(mydrglist[myidx], paste(input$sourcedrg, collapse=" ") )
      }
      ischkmyptslist <- rep(FALSE, length(myptslist))
      for( myidx in 1:length(myptslist)){
        ischkmyptslist[myidx] <- grepl(myptslist[myidx], paste(input$sourcepts, collapse=" ") )
      }
      isdmednameexact<-":"
      isdgennameexact<-":"
      isptexact<-":"
      if(!is.null(input$setdmednameexact)){if(input$setdmednameexact){isdmednameexact<-".exact:"}}
      if(!is.null(input$setdgennameexact)){if(input$setdgennameexact){isdgennameexact<-".exact:"}}
      if(!is.null(input$setptexact      )){if(input$setptexact){isptexact<-".exact:"}}
      myurlbeg <- "https://api.fda.gov/drug/event.json?search="
      myurlrep <- paste(list(
        gsub("-","",paste("receivedate:[",input$setrecdate[1], "+TO+",input$setrecdate[2],"]")),
        paste("primarysource.qualification:", input$setprisource),
        paste("serious:", input$setserious),
        paste("sendertype:", input$setsendert),
        paste("receiver.receivertype:", input$setreceiver)
      )[ischkmyreplist], collapse="+AND+")
      myurlpat <- paste(list(
        paste("patient.patientonsetage:[",input$setonsetage[1],"+TO+", input$setonsetage[2],"]"),
        paste("patient.patientsex:",input$setpgender),
        paste("patient.patientweight:[",input$setpweight[1],"+TO+",input$setpweight[2],"]")
      )[ischkmypatlist], collapse="+AND+")
      myurldrg <- paste(list(
        paste("patient.drug.medicinalproduct",isdmednameexact,shQuote(toupper(gsub(" ", "+", input$setdmedname)), type="cmd"), sep=""),
        paste("patient.drug.openfda.generic_name",isdgennameexact,shQuote(toupper(gsub(" ", "+", input$setdgenname)), type="cmd"), sep="")
      )[ischkmydrglist[c(1,3)]], collapse="+AND+")
      myurlpts <- paste(list(
        paste("(patient.reaction.reactionmeddrapt",isptexact,shQuote(toupper(gsub(" ","+",input$setpt)), type="cmd"),")", sep="")
      )[ischkmyptslist[c(1)]], collapse="+AND+")

      myurlend=NULL
      if(!is.null(input$sourcedrg) & !is.null(input$sourcepts)){
        myurlend <- paste(myurldrg, "+AND+", myurlpts, sep="" )
      }else{if(!is.null(input$sourcedrg) | !is.null(input$sourcepts)){
        myurlend <- paste(myurldrg, myurlpts, sep="" )}}
      if(!is.null(input$sourcepat) & !is.null(myurlend)){
        myurlend <- paste(myurlpat, "+AND+", myurlend, sep=""  )
      }else{if(!is.null(input$sourcepat) | !is.null(myurlend)){
        myurlend <- paste(myurlpat, myurlend, sep="" )}}
      if(!is.null(input$sourcerep) & !is.null(myurlend)){
        myurlend <- paste(myurlrep, "+AND+", myurlend, sep="" )
      }else{myurlend <- paste(myurlrep, myurlend, sep="") }

      if(input$sourcertn=="r"){myurlrtn="&limit=1"}
      if(input$sourcertn=="p"){myurlrtn="&count=patient.reaction.reactionmeddrapt.exact"}
      if(input$sourcertn=="d"){myurlrtn="&count=patient.drug.openfda.generic_name.exact"}
      if(input$sourcertn=="c"){myurlrtn="&count=receivedateformat"}
      gsub("\\s", "", paste(myurlbeg, myurlend, myurlrtn))
    }

    output$myquery <- renderText({
      values$myurlstr <- myurl()
      values$myurlstr })

    output$mysubmit <- renderText({ paste('<a href="', values$myurlstr,'", class="btn btn-info"> Download in JSON format </a>', sep="") })

    observeEvent(input$mycopy, { writeClipboard(values$myurlstr, format = 1) })

    observeEvent(input$myjview, { renderText({ values$myurlstr }) })
  })
)

#' A user interface for generating query url for the openFDA website
#'
#' @param none
#' @export
genqueryUI <- function(){
  runApp(appgenquerryui)
}


