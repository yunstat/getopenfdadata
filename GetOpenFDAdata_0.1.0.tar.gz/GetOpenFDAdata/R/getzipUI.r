appgetzipui <- shinyApp(
  ui = shinyUI(
    fluidPage(theme = "bootstrap.css",
      tags$head(
        tags$style(HTML("h2 {
                                           font-family: 'Lobster', cursive;
                                           font-weight: 500;
                                           line-height: 1.1;
                                           color: #3366aa;
                                           }
                                           ")
        )
      ),
      titlePanel("Download ZIP files from the openFDA website"),
        fluidRow(
          column(12,
            fluidRow(
              useShinyjs(),
                column(3,tags$h3("Infomation:"),
                  wellPanel(uiOutput("downloadinfoui"))
                ),
                column(9,
                  tabsetPanel(
                    tabPanel("Download single zip file",dataTableOutput("downloadtbl")),
                    tabPanel("Batch Downlyad by year",
                      uiOutput("downloadsetyr"),tags$br(),
                      tags$b("Warning>> Enough free disk space is required", class="alert alert-dismissible alert-warning"),
                      tags$br(), tags$br(),
                      tags$b("Warning>> The downloading process may take very long time.", class="alert alert-dismissible alert-warning"),
                      tags$br(), tags$br(),
                      actionButton("downloaduilocal", label = "Download and unzip selected files", class = "btn btn-warning"),
                      tags$br(), tags$br(),
                      tags$b("Info>> The button will be enabled after the process finished.", class="alert alert-dismissible alert-info")
                    ),
                    tabPanel("JSON to CSV",
                      uiOutput("listlocaljson"),tags$br(),
                      tags$b("Warning>> At least 16GB free memory is suggested.", class="alert alert-dismissible alert-warning"),
                      tags$br(), tags$br(),
                      tags$b("Warning>> ALL existing csv files in the working directory will be deleted.", class="alert alert-dismissible alert-warning"),
                      tags$br(), tags$br(),
                      actionButton("jsontocsvbyyear", label = "Save PT and drug_name in seperate files with safetyid", class = "btn btn-warning"),
                      tags$br(), tags$br(),
                      tags$b("Info>> The button will be enabled after the process finished.", class="alert alert-dismissible alert-info")
                    ),
                    tabPanel("JSON to CSV with cov",
                      tags$br(),
                      tags$br(), tags$br(), tags$b("at work.")
                    ),tabPanel("About", column(12, source(file="./R/info/about.r")))
                  ) #tabsetPanel
                ) #column
              ) #fluidrow
            ) #column
          ), #fluidrow
          fluidRow(tags$hr(), source(file="./R/info/footnote.r"))
        )
      ), # UI

      ######################################################################
      server = shinyServer(function(input, output, session) {
        values <- reactiveValues()
        mygetdlinfo <- function(){
          zipfileinfourl <- "https://api.fda.gov/download.json"
          zipfileinfojson <- httr::GET(zipfileinfourl)
          if (zipfileinfojson$status_code == 404) {
            warning('Received 404 response from server.\n',
                'Interpreting as an empty set.')
            return(data.frame(zipfileinfojson=c()));
          }
          httr::stop_for_status(zipfileinfojson)
          fromJSON(paste(httr::content(zipfileinfojson, as='text'), collapse=""))
        }
        mygetdlinfotbl <- function(myjobj){
          mytotnfile <- length(myjobj$results$drug$event$partitions)
          zipfilelistsize <- rep("",mytotnfile)
          zipfilelistnrec <- rep(0,mytotnfile)
          zipfilelistname <- rep("",mytotnfile)
          zipfilelisturl  <- rep("",mytotnfile)
          for( myidx in 1:mytotnfile ){
            zipfilelistsize[myidx] <- myjobj$results$drug$event$partitions[[myidx]]$size_mb
            zipfilelistnrec[myidx] <- myjobj$results$drug$event$partitions[[myidx]]$records
            zipfilelistname[myidx] <- myjobj$results$drug$event$partitions[[myidx]]$display_name
            zipfilelisturl[myidx]  <- myjobj$results$drug$event$partitions[[myidx]]$file
          }
          zipfilelistid <- gsub("\\s", "", zipfilelistname)
          zipfilelistid <- gsub("\\(", "", zipfilelistid)
          zipfilelistid <- gsub("\\)", "", zipfilelistid)
          zipfilelistlink <-
          paste('<a id="',zipfilelistid,'" href="',zipfilelisturl,
              '" target="_blank" class="btn btn-default" icon="download">Download</a>', sep="")
          zipfilelistdf <- data.frame(name=zipfilelistname, filesize=zipfilelistsize,
                                  recinfile=zipfilelistnrec, download=zipfilelistlink,
                                  fileurl=zipfilelisturl, id=zipfilelistid)
          zipfilelistdf$year <- substr(zipfilelistname, 1, 4)
          zipfilelistdf$year[zipfilelistdf$year=="All "] <- "Other"
          mytmp <- strsplit(zipfilelistname, " of ")
          for( myidx in 1:mytotnfile ){
            zipfilelistdf$totnpart[myidx] <- gsub("\\)","",strsplit(zipfilelistname[myidx], " of ")[[1]][2])
          }
      #    zipfilelistdf$quarter <- ssubstr(zipfilelistname, 7, 7)
      #    zipfilelistdf$part <- substr(zipfilelistname, 15, 15)
      #    zipfilelistdf$quarter[zipfilelistdf$quarter=="h"]<-"1"
      #    zipfilelistdf$part[zipfilelistdf$part=="" | zipfilelistdf$part==" "]<-"1"
          zipfilelistdf
        }

        output$downloadtbl <- renderDataTable({
          values$myrvdlinfo <- mygetdlinfo()
          values$myrvdlinfotbl <- mygetdlinfotbl(values$myrvdlinfo)
          values$myrvdlinfotbl[,c(1,2,3,4)]
        }, options = list(pageLength=10), escape=FALSE)

        output$downloadinfoui <- renderUI({
          zipfileinfor <- values$myrvdlinfo
          mytotnfile <- length(zipfileinfor$results$drug$event$partitions)
          list(
            tags$b("openFDA disclaimer: "),      tags$p(zipfileinfor$meta["disclaimer"]),
            tags$b("openFDA license: "),         tags$p(zipfileinfor$meta["license"]),
            tags$b("Total number of reports: "), tags$p(zipfileinfor$results$drug$event$total_records),
            tags$b("Last updated: "),            tags$p(tags$strong(zipfileinfor$meta["last_updated"]),  class="text-danger"),
            tags$b("Total number of files: "),   tags$p(mytotnfile),
            tags$b("Export date: "),             tags$p(zipfileinfor$results$drug$event$export_date)
          )
        })

        output$downloadsetyr <- renderUI({
          zipfileinfotdf <- values$myrvdlinfotbl
          zipfileinfotdf$cnt <- 1
          zipfilelistyr <- data.frame(xtabs(as.numeric(cnt) ~ year, zipfileinfotdf))
          names(zipfilelistyr) <- c("Year", "nFiles")
          zipfilelistyr$nFiles <- as.character(zipfilelistyr$nFiles)
          zipfilelistyr$TotalSize_MB <-as.character(xtabs(as.numeric(as.character(filesize)) ~ year, zipfileinfotdf))
          zipfilelistyr$TotalRecords <-as.character(xtabs(as.numeric(as.character(recinfile)) ~ year, zipfileinfotdf))
          zipfilelistnyear <- as.numeric(as.character(zipfilelistyr$Year[zipfilelistyr$Year!="Other"]))
          list(
            sliderInput("setdlyearrange", label="Select year(s):",step=1,width="95%",
                    min = min(zipfilelistnyear), max = max(zipfilelistnyear), value = c(2004,2004)),
            renderTable(zipfilelistyr)
          )
        })

        observeEvent(input$downloaduilocal, {
          zipfileinfotdf <- values$myrvdlinfotbl
          disable("downloaduilocal")
          for(myidx in input$setdlyearrange[1]:input$setdlyearrange[2]){
            listzipurl <- as.character(zipfileinfotdf$fileurl[zipfileinfotdf$year==as.character(myidx)])
            listzipid   <- as.character(zipfileinfotdf$id[zipfileinfotdf$year==as.character(myidx)])
            for(myidx2 in 1:2){
            #for(myidx2 in 1:length(listzipurl)){
              mytmpname <- strsplit(listzipurl[myidx2], '/', fixed=TRUE)[[1]][c(6,7)]
              mytmpname[2] <- paste(strsplit(mytmpname[2],'-',fixed=TRUE)[[1]][-c(1,2)],collapse="_")
              if(mytmpname[1]=="all_other"){mytmpname[1]="0000q0"}
              zipdestfilename <- paste(mytmpname,collapse="_")
              dlmessage <- download.file(url=listzipurl[myidx2], destfile=zipdestfilename, quiet=FALSE,mode="wb",method="wininet")
              mytmpjsonname <- unzip(zipfile=zipdestfilename)
              if(length(mytmpjsonname)==1){
                file.rename( from=mytmpjsonname, to=strtrim(zipdestfilename, nchar(zipdestfilename)-4))
              }
            }
          }
          enable("jsontocsvbyyear")
        })

        output$listlocaljson <- renderUI({
          values$mylistjson <- list.files(path = getwd(), pattern=".json$")
          mycsvpath <- getwd()
          if(length(values$mylistjson)==0){wellPanel(
            tags$b("No JSON file was found.")
          )}else{
            mylistjsonyr <- substr(values$mylistjson, 1, 4)
        mylistuniqyr <- unique(mylistjsonyr)
        wellPanel(
          tags$b("Working directory (Warning: ALL csv files in this folder will be deleted.): "), tags$p(mycsvpath),
          tags$br(),
          checkboxGroupInput(inputId="chkjsonfile", label="Select JSON file(s) by year:",
                             choices=mylistuniqyr
          )
        )
      }
    })

    myjsontocsvsep <- function(myjsfilename){
      jsoncontents  = fromJSON(content=myjsfilename)
      mytotalreport = length(jsoncontents$results)
      mycntday  = 0
      mycuryear = 0
      mypredate = ""
      for( myidxrep in 1:mytotalreport){
        myonereport <- jsoncontents$results[[myidxrep]]
        if( min(length(myonereport$patient$reaction),length(myonereport$patient$drug),length(myonereport$safetyreportid))==0 ){next}
        if(is.atomic(myonereport$patient$drug)){ next }else{
          mytmpdruglength <- length(myonereport$patient$drug)
        }
        if(is.atomic(myonereport$patient$reaction)){ next }else{
          mytmprectlength <- length(myonereport$patient$reaction)
        }
        for( myidxdrug in 1:mytmpdruglength ){
          if(!is.null(myonereport$patient$drug[[myidxdrug]]['medicinalproduct'])){
            mytmpdncsv <- rbind(mytmpdncsv, c(myonereport$safetyreportid, myonereport$patient$drug[[myidxdrug]]['medicinalproduct'][[1]]))
          }
          if(is.atomic(myonereport$patient$drug[[myidxdrug]]['openfda'])){next}
          if(!is.null(myonereport$patient$drug[[myidxdrug]]$openfda)){
            if(!is.null(myonereport$patient$drug[[myidxdrug]]$openfda['generic_name'])){
              mytmpgncsv <- rbind(mytmpgncsv, c(myonereport$safetyreportid, myonereport$patient$drug[[myidxdrug]]$openfda['generic_name'][[1]][1]))
            }
          }
        }
        for( myidxpt in 1:mytmprectlength){
          if(!is.null(myonereport$patient$reaction[[myidxpt]])){
            mytmpptcsv <- rbind(mytmpptcsv, c(myonereport$safetyreportid, myonereport$patient$reaction[[myidxpt]]))
          }
        }
        mycurrentdate=paste(substr(myonereport$receivedate,1,4),'-',substr(myonereport$receivedate,5,6),'-',substr(myonereport$receivedate,7,8), sep="")
        mycurrentdinyr=as.character(as.numeric(strftime(mycurrentdate, format="%j")))
        if(!is.null(mytmpptcsv)){
          write.table(mytmpptcsv, file=paste("./csvbyday/",
                                             substr(mycurrentdate, 1, 4),"PTDay", mycurrentdinyr,".csv",sep=""),
                      append=TRUE, row.names=FALSE, col.names=FALSE, sep="$", quote=FALSE)
          mytmpptcsv <- NULL
        }
        if(!is.null(mytmpdncsv)){
          write.table(mytmpdncsv, file=paste("./csvbyday/",
                                             substr(mycurrentdate, 1, 4),"DNDay", mycurrentdinyr,".csv",sep=""),
                      append=TRUE, row.names=FALSE, col.names=FALSE, sep="$", quote=FALSE)
          mytmpdncsv <- NULL
        }
        if(!is.null(mytmpgncsv)){
          write.table(mytmpgncsv, file=paste("./csvbyday/",
                                             substr(mycurrentdate, 1, 4),"GNDay", mycurrentdinyr,".csv",sep=""),
                      append=TRUE, row.names=FALSE, col.names=FALSE, sep="$", quote=FALSE)
          mytmpgncsv <- NULL
        }
      }
    }

    observeEvent(input$jsontocsvbyyear, {
      mylistjsonfn <- length(values$mylistjson)
      mylistjsonyr <- substr(values$mylistjson, 1, 4)
      mylistjsonchked <- paste(input$chkjsonfile, collapse=" ")
      if( mylistjsonfn > 0 ){
        disable("jsontocsvbyyear")
        if( !file.exists("./csvbyday") ){dir.create("./csvbyday")}else{
          mytmplistcsv <- list.files("./csvbyday", pattern=".csv$")
          if(length(mytmplistcsv)>0){
            file.remove(paste("./csvbyday/",mytmplistcsv, sep=""))
          }
        }
        for( myidx in 1:mylistjsonfn){
          if(grepl(mylistjsonyr[myidx],  mylistjsonchked)==TRUE){
            myjsontocsvsep(values$mylistjson[myidx])
          }
        }
        myidx=0
        mypreyear=""
        enable("jsontocsvbyyear")
      }
    })

    observeEvent(input$jsontocsvpairs, {
      mylistjsonfn <- length(values$mylistjson)
      mylistjsonyr <- substr(values$mylistjson, 1, 4)
      mylistjsonchked <- paste(input$chkjsonfile, collapse=" ")
      if( mylistjsonfn > 0 ){
        if( !file.exists("./csvbyday") ){dir.create("./csvbyday")}
        for( myidx in 1:mylistjsonfn){
          if(grepl(mylistjsonyr[myidx],  mylistjsonchked)==TRUE){
            #          myjsontocsvpair(value$mylistjson[myidx])
          }
        }
        myidx=0
        mypreyear=""
      }
    })

  })
)


#' A graphical user interface for downloading data from the openFDA website
#'
#' @param zipdir the path for storing downloaded zip files
#' @examples
#' getzipUI(outzipdir="c:/Users/Myname/Documents/")
#' @seealso \code{\link{genqueryUI}}
#' @export
getzipUI <- function( outzipdir ){
  if(!is.character(outzipdir) | is.na(outzipdir) | length(outzipdir)>1 | nchar(outzipdir)<=1 ){
    return(c(-1,"The path is not vaild."))
  }
  if( !file.exists(outzipdir) ){
    return(c(-1,"The path does not exist."))
  }
  currentsetwd <- getwd()
  setwd(outzipdir)
  if( interactive() ){
    runApp(appgetzipui)
  }
  setwd(currentsetwd)
}


